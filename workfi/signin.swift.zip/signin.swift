//
//  signin.swift
//  workfi
//
//  Created by Sara Anwar on 8/29/19.
//  Copyright © 2019 Sara Anwar. All rights reserved.
//

import UIKit

struct Country : Decodable {
    let shop_id: String
    let shop_name: String
    let shop_logo: String
    let subdomain: String
    let food_currency_id: String
}

/* extension URL {
    public var queryParameters: [String: String]? {
        guard
            let components = URLComponents(url: self, resolvingAgainstBaseURL: true),
            let queryItems = components.queryItems else { return nil }
        return queryItems.reduce(into: [String: String]()) { (result, item) in
            result[item.name] = item.value
        }
    }
    
    let test1 = getQueryStringParameter(url:"http://mysite3994.com?test1=blah&test2=blahblah", param: "test1")
}
*/
class signin: UIViewController {
    
    
    @IBOutlet weak var password: UITextField!
    @IBOutlet weak var username: UITextField!
    @IBOutlet weak var signin: UIButton!
    @IBOutlet weak var signup: UIButton!
    @IBOutlet weak var forgot: UIButton!
        override func viewDidLoad() {
        super.viewDidLoad()
            guard let url = URL(string: "https://www.foodchow.com/api/FoodChowRMS/LoginWD?eid=testing@tenacioustechies.com&pwd=123456&device_type=0&device_id=&token=") else {return}
            let task = URLSession.shared.dataTask(with: url) { (data, response, error) in
                guard let dataResponse = data,
                    error == nil else {
                        print(error?.localizedDescription ?? "Response Error")
                        return }
                do{
                    //here dataResponse received from a network request
                    let jsonResponse = try JSONSerialization.jsonObject(with:
                        dataResponse, options: [])
                    print(jsonResponse) //Response result
                } catch let parsingError {
                    print("Error", parsingError)
                }
            }
            task.resume()
        
            let defaults = UserDefaults.standard
            defaults.set(1409, forKey: "ShopId")
            defaults.set("FoodChow Demo", forKey: "ShopName")
            defaults.set("1409_2019-06-20_14-22-59.png", forKey: "ShopLogo")
            defaults.set("foodchow-demo", forKey: "Subdomain")
            defaults.set("INR", forKey: "FoodCurrencyId")

    }
    
}
